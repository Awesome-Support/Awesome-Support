<head>

	<link rel="stylesheet" href="includes/wpas_editor_email_template_tags.css" />
</head>

<body>

	<?php
    echo '<div>';
    	
    	echo '<p id="instructions"></p>';
		echo '<div id="template_tags"></div>';
    echo '</div>';
	?>
    
    <script type="text/javascript" src="includes/wpas_editor_email_template_tags.js"></script>
</body>