<div class="about-text"><b>To get started quickly please click the <em>GETTING STARTED</em> tab to the right of this one for some quick instructions on what to do next!</b></div>

<hr />	
<div>
	<div class="changelog">

		<div class="row">
			<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
				<div class="about-body">
					<a class="wpas-bundle-link" href="https://getawesomesupport.com/addons/startup-bundle/" target="_blank">
						<img src="<?php echo WPAS_URL; ?>assets/admin/images/StartupBundle-2_Blue.png" alt="Startup Bundle">	
					</a>		
				</div>
			</div>				
			<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">				
				<div class="about-body">
					<a class="wpas-bundle-link" href="https://getawesomesupport.com/addons/professional-bundle/" target="_blank">
						<img src="<?php echo WPAS_URL; ?>assets/admin/images/ProfessionalBundle-1_Red.png" alt="Professsional Bundle">	
					</a>		
				</div>
			</div>
		</div>
		<hr />						
	</div>
</div>

