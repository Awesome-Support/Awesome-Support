The files in this folder will be removed in the next update of Awesome Support.
The locale names on these files are incorrect according to the translate.wordpress.org.
